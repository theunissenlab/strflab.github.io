%% Direct Fit training routine
%
%   Input:
%       modelParams: 
%
%       datIdx:
%
%       options:
%           .tolerances: a vector of tolerance values to use
%           .separable: 0=space-time separable, 1=non-separable (defaults to 1)
%           .timeVaryingPSTH: whether the time-varying PSTH should be
%               subtracted from each sample (defaults to 0)
%           .timeVaryingPSTHTau: width of hanning window used to smooth
%               time-varying PSTH in ms (defaults to 41)
%           .stimSampleRate: post-preprocessing stimulus sampling rate in
%               Hz (defaults to 1000)
%           .respSampleRate: response sampling rate in Hz (defaults to
%               1000)
%           .outputDir: directory where all the stuff goes (defaults to
%               tempdir)
%
%   Output:
%       modelParams: 
%
%       options:
%
function [modelParams, options] = trnDirectFit(modelParams, datIdx, options, varargin)
    
    %% set default parameters and return if no arguments are passed
    if nargin == 0
       options = struct;
       options.funcName = 'trnDirectFit';
       options.tolerances = [0.100 0.050 0.010 0.005 1e-03 5e-04 1e-04 5e-05];
       options.separable = 0;
       options.timeVaryingPSTH = 0;
       options.timeVaryingPSTHTau = 41;
       options.stimSampleRate = 1000;
       options.respSampleRate = 1000;
       options.outputDir = tempdir();
       
       modelParams = options;
       
       return;
    end
    
    if ~strcmp(modelParams.type, 'lin') || ~strcmp(modelParams.outputNL, 'linear')
        error('trnDirectFit only works for linear models with no output nonlinearity!\n');
    end
    
    global globDat;
    
    %% convert strflab's stim/response data format to direct fit's data format
    DS = strflab2DS(globDat.stim, globDat.resp, globDat.groupIdx, options.outputDir);
    
    %% set up direct fit parameters
    params = struct;

    params.DS = DS;
    params.NBAND = size(globDat.stim, 2);
    params.Tol_val = options.tolerances;
    params.setSep = options.separable;
    params.TimeLag = length(modelParams.delays);
    params.TimeLagUnit = 'msec';
    params.timevary_PSTH = options.timeVaryingPSTH;
    params.smooth_rt = options.timeVaryingPSTHTau;
    params.ampsamprate = options.stimSampleRate;
    params.respsamprate = options.respSampleRate;
    params.outputPath = options.outputDir;
    params.use_alien_space = 0;
    params.alien_space_file = '';
    
    %% run direct fit
    strfFiles = direct_fit(params);
        
    %% get computed stim and response means 
    svars = load(fullfile(options.outputDir, 'stim_avg.mat'));
    stimAvg = svars.stim_avg;
    respAvg = svars.constmeanrate;
    tvRespAvg = svars.Avg_psth;
    clear svars;
    
    %% subtract means from stimuli
    meanSubtractedStim = globDat.stim;
    for k = 1:size(meanSubtractedStim, 1)
       meanSubtractedStim(k, :) = meanSubtractedStim(k, :) - stimAvg'; 
    end
    
    %% compute information values for each set of jacknifed strfs per tolerance value
    infoVals = zeros(length(strfFiles), 1);
    for k = 1:length(strfFiles)       
        svars = load(strfFiles{k});
        strfs = svars.STRFJN_Cell;
        clear svars;
        
        njnStrfs = size(strfs, 3);
        for j = 1:njnStrfs
            
            strf = strfs(:, :, j);
            %split in half
            sIndx = round(size(strf, 2) / 2);
            strf = strf(:, sIndx:size(strf, 2));
           
            %compute response for left out stimulus
            rng = find(globDat.groupIdx == j);
            stim = meanSubtractedStim(rng, :);
            mresp = convolve_strf(stim', strf);
            %add the mean back to the PSTH (it was subtracted by direct fit)
            if ~options.timeVaryingPSTH
                mresp = mresp + respAvg;
            else
                mresp = mresp + tvRespAvg(j, 1:length(mresp));
            end
            
            psth = globDat.resp(rng);
            %compute info value
            cStruct = compute_coherence_mean(mresp, psth, options.respSampleRate);
            infoVals(k) = infoVals(k) + cStruct.info;
        end        
        clear strfs;
    end
    
    %% get best strf
    [maxInfo, maxIndx] = max(infoVals);
    sfile = strfFiles{maxIndx};
    svars = load(sfile);
    strf = svars.STRF_Cell;
    clear svars;
    
    %split in half
	sIndx = round(size(strf, 2) / 2);
    strf = strf(:, sIndx:size(strf, 2));
    
    modelParams.w1 = strf;
    modelParams.b1 = 0;
    