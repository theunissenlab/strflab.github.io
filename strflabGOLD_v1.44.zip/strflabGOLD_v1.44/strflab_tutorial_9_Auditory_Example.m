%% Auditory example

%% get the directory that this file resides in
strflabDir = get_function_dir('strflab_tutorial_9_Auditory_Example');
if isempty(strflabDir)
    error('Cannot find strflab directory!');
end

%% make sure strflab functions are in matlab path
addpath(genpath(strflabDir))
global globDat

%% specify where wav files and spike files are
dataDir = fullfile(strflabDir, 'fakedata', 'auditory');

%% get list of stim and response files
stimFiles = get_filenames(dataDir, 'stim[0-9]*.wav', 1);
respFiles = get_filenames(dataDir, 'spike[0-9]*', 1);
  
%% preprocess stimuli and responses, by default uses short-time FT
srData = preprocess_sound(stimFiles, respFiles);

%% convert stim/response representation to strflab representation
[allstim, allresp, groupIndex] = srdata2strflab(srData);

%% subtract means from stim and responses
numTimePoints = size(allstim, 1);
for k = 1:numTimePoints
    allstim(k, :) = allstim(k, :) - srData.stimAvg';
end
allresp = allresp - srData.respAvg;

%% Put stimulus and response and group assignments into globDat
strfData(allstim, allresp, groupIndex);

%% Exclude data from the 12th stimulus from training
datIdx = find(groupIndex ~= 12);

useEarlyStopping = 1;

%% Set options for gradient descent
options = trnGradDesc;
options.display = 1;
options.coorDesc = 0;
options.earlyStop = useEarlyStopping;
options.stepSize = 1e-5;
options.nDispTruncate = 0;
options.maxIter = 1000;

%% Initialize strf with up to 75 delays because we are using very small time bins
modelParams = linInit(size(allstim,2), 0:74);

%% set the bias term to the mean firing rate
modelParams.b1 = 0;

if useEarlyStopping
    %% Use 80% of the data for training
    trainingIdx = 1:floor(.8*size(datIdx,2));

    %% Use the remaining 20% for the stopping set
    stoppingIdx = floor(.8*size(datIdx,2))+1:size(datIdx,2);

    %% train the strf
    [strfTrained, options] = strfOpt(modelParams, datIdx(trainingIdx), options, datIdx(stoppingIdx));
else
    %% train the strf
    [strfTrained, options] = strfOpt(modelParams, datIdx, options);
end
    
%% try prediction using the held out 12th stimulus
datIdxPred = find(groupIndex == 12);
[strfTrained, predResp] = strfFwd(strfTrained, datIdxPred);
% add mean to response
predResp = predResp + srData.respAvg;
realResp = allresp(datIdxPred);

%compute coherence for validation
sampleRate = 1000;
cStruct = compute_coherence_mean(predResp, realResp', sampleRate);

%% make plots
figure; hold on;
subplot(2, 2, 1);
imagesc(squeeze(strfTrained.w1));
title('STRF');
axis tight;

subplot(2, 2, 2); hold on;
plot(cStruct.f, cStruct.c, 'k--');
plot(cStruct.f, cStruct.cUpper, 'b-');
plot(cStruct.f, cStruct.cLower, 'r-');
legend('Mean', 'Upper', 'Lower');
title(['Coherence | Info=' num2str(cStruct.info) ' bits']);
axis tight;

subplot(2, 2, [3 4]); hold on;
plot(realResp', 'k-');
plot(predResp, 'r');
axis tight;

%{
%% Let's trying fitting this STRF with a new (and somewhat experimental) fitting routine
%% trnPF is a algorith that lets you choose an arbitrary Tikhonov regularization matrix, and 
%% decreases the strength of the prior until the STRF's ability to generalize to a stopping
%% set gets worse
options = trnPF;
options.display=-1;
options.maxIter = 1000;
options.lamdaInit = 20000000;
options.errLastN = 10;

%% We're going to specify a smooth prior the size of our weights so that weights change
%% smoothly in time and space
options.A = full(getSmoothnessPrior([size(squeeze(strf.w1)) 1], [1 1 0]));

%% the last term in the matrix would be for the bias term, but the bias should not be smooth
%% with respect to the other parameters so we set this to 0
options.A(end+1,end+1) = 0;

%% Train and viusalize the STRF
strfTrained=strfOpt(strf,trainingIdx,options,stoppingIdx);


%% try prediction using the held out 12th stimulus
datIdxPred =find(assign ==12);
[strfTrained,predResp]=strfFwd(strfTrained,datIdxPred);
sp = allspike(datIdxPred);
corr(sp',predResp)
figure;
plot(sp'); hold on; plot(predResp, 'r')

%% the weights are basically a spectrogram so lets look at them
figure; imagesc(squeeze(strfTrained.w1))

%%


%% We're going to specify a smooth prior the size of our weights so that weights change
%% smoothly in time and space
options.A = eye(prod(size(strf.w1)));

%% the last term in the matrix would be for the bias term, but the bias should not be smooth
%% with respect to the other parameters so we set this to 0
options.A(end+1,end+1) = 0;

%% Train and viusalize the STRF
strfTrained=strfOpt(strf,trainingIdx,options,stoppingIdx);


%% try prediction using the held out 12th stimulus
datIdxPred =find(assign ==12);
[strfTrained,predResp]=strfFwd(strfTrained,datIdxPred);
sp = allspike(datIdxPred);
corr(sp',predResp)
figure;
plot(sp'); hold on; plot(predResp, 'r')

%% the weights are basically a spectrogram so lets look at them
figure; imagesc(squeeze(strfTrained.w1))


%}