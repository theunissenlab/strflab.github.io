function modelResponses = compute_predictions(srData, strf, wereMeansSubtracted, wasTimeVarying)

    if nargin < 3
        wereMeansSubtracted = 0;
    end
    if nargin < 4
        wasTimeVarying = 0;
    end

    pairCount = length(srData.datasets);
    modelResponses = cell(pairCount, 1);
    
    for k = 1:pairCount
       
        ds = srData.datasets{k};
        stim = ds.stim.tfrep.spec;
        
        if wereMeansSubtracted
            %subtract mean from spectrogram
            for t = 1:size(stim, 2)
               stim(:, t) = stim(:, t) - srData.stimAvg(:); 
            end
        end
        
        %convolve stim with strf
        mpsth = convolve_strf(stim, strf);
        
        if wereMeansSubtracted
            %add means to response
            if wasTimeVarying
                indx = 1:length(mpsth);
                mpsth = mpsth + srData.tvRespAvg(k, indx);
            else
                mpsth = mpsth + srData.respAvg;                
            end            
        end
        %rectify
        mpsth(mpsth < 0) = 0;
        
        modelResponses{k} = mpsth;        
    end