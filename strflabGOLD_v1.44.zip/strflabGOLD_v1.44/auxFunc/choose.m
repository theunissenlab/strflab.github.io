function f = choose(flag,yes,no)

% function f = choose(flag,yes,no)
%
% <flag> is 0/1
% <yes> is something
% <no> is something
%
% if <flag>, return <yes>.  otherwise, return <no>.

if flag
  f = yes;
else
  f = no;
end
