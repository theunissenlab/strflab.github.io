function out = df_get_local_cache_dir
global DF_PARAMS
out = fullfile(DF_PARAMS.outputPath,'local_cache_dir');